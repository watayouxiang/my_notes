
1.mVersion
Livedata类中的成员变量

2.mLastVersion

SafeIterableMap<Observer<? super T>, ObserverWrapper> mObservers
mObservers.iteratorWithAdditions()
iterator.next().getValue()
ObserverWrapper observer
observer.mLastVersion
