玩遍Jetpack核心支持库之Lifecycle与Livedata
主要内容：
1.Lifecycle的使用与实现原理    ok
2.Jetpack中的状态机如何管理生命周期   ok

3.Livedata使用与实现原理分析
4.Livedata粘性事件源码分析
5.hook实现Livedata非粘性功能
6.Livedata递归调用源码中如何做容错
7.企业级LivedataBus封装实现
