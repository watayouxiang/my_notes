package com.higher.maniuservice;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.IntentService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.view.View;

import com.higher.maniuservice.service.SimpleIntentService;
import com.higher.maniuservice.service.SimpleService;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Intent intent;
    private SimpleService.SimpleBinder mBinder;
    private IntentService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.start).setOnClickListener(this);
        findViewById(R.id.bind).setOnClickListener(this);
        findViewById(R.id.unbind).setOnClickListener(this);
        findViewById(R.id.stop).setOnClickListener(this);
        //AIDL
        intent = new Intent("xxxx.xxxx.xxService");
    }


    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.e(SimpleService.TAG, "onServiceConnected");
            mBinder = (SimpleService.SimpleBinder) service;
            mBinder.doTask();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(SimpleService.TAG, name.toString());
        }

    };

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start:
                startService(intent);
                break;
            case R.id.bind:
                bindService(intent, mConnection, BIND_AUTO_CREATE);
                break;
            case R.id.unbind:
                unbindService(mConnection);
                break;
            case R.id.stop:
                stopService(intent);
                break;
        }
    }
}