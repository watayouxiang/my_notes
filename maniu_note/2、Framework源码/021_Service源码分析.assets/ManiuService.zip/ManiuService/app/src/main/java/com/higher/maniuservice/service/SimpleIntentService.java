package com.higher.maniuservice.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.Nullable;

public class SimpleIntentService extends IntentService {
    public SimpleIntentService() {
        super("SimpleIntentService");
    }


    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(SimpleService.TAG, "onCreate");
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        Log.e(SimpleService.TAG, "onStart");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        startForeground();
        Log.e(SimpleService.TAG, "onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(SimpleService.TAG, "onDestroy");
    }

    //执行在子线程
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.e(SimpleService.TAG, "onHandleIntent");
    }
}
