package com.higher.lazyfragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LogFragment extends Fragment {
    public static String TAG = "MANIU";

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.e(TAG, "onAttach" + getClass().getName());
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, "onCreate" + getClass().getName());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView" + getClass().getName());
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        Log.e(TAG, isVisibleToUser + " setUserVisibleHint " + getClass().getName());
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public void onStart() {
        Log.e(TAG, "onStart" + getClass().getName());
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.e(TAG, "onResume" + getClass().getName());
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.e(TAG, "onPause" + getClass().getName());
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.e(TAG, "onStop" + getClass().getName());
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        Log.e(TAG, "onDestroyView" + getClass().getName());
        super.onDestroyView();
    }

    @Override
    public void onDetach() {
        Log.e(TAG, "onDetach" + getClass().getName());
        super.onDetach();
    }

    @Override
    public void onDestroy() {
        Log.e(TAG, "onDestroy" + getClass().getName());
        super.onDestroy();
    }
}
