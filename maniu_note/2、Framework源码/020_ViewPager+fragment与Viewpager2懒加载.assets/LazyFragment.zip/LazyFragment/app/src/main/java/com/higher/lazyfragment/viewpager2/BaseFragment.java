package com.higher.lazyfragment.viewpager2;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
    View rootView;
    public static String TAG = "MANIU";
    public boolean currentVisibleState;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView " + getClass().getName());
        rootView = inflater.inflate(getLayoutId(), container, false);
        initView(rootView);
        return rootView;
    }

    protected abstract void initView(View rootView);

    protected abstract int getLayoutId();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, "onCreate  " + getClass().getName());
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.e(TAG, "onActivityCreated  " + getClass().getName());
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e(TAG, "onStart  " + getClass().getName());
    }

    boolean isLoaded;

    @Override
    public void onResume() {
        super.onResume();
        if (!isLoaded) {
            loadData();
            isLoaded = true;
        }
        Log.e(TAG, "onResume  " + getClass().getName());
    }

    protected void loadData(){

    };

    @Override
    public void onPause() {
        super.onPause();
        Log.e(TAG, "onPause  " + getClass().getName());
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.e(TAG, "onStop  " + getClass().getName());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy " + getClass().getName());
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.e(TAG, "onDetach " + getClass().getName());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e(TAG, "onDestroyView " + getClass().getName());
        isLoaded = false;
    }

}
