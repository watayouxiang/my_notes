package com.higher.lazyfragment.fragment;

import android.view.View;
import android.widget.TextView;

import com.higher.lazyfragment.LazyFragment;
import com.higher.lazyfragment.LazyFragment2;
import com.higher.lazyfragment.R;

import java.util.ArrayList;

public class Fragment1 extends LazyFragment {

    private ArrayList<Integer> array;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment;
    }


    private TextView textView;

    @Override
    protected void initView(View rootView) {
        textView = rootView.findViewById(R.id.fragment_tv);
        textView.setText("初始化页面" );
    }

    @Override
    public void loadData() {
        super.loadData();
        array = new ArrayList(1024 * 1024 * 7);
        textView.setText("加载数据" );
    }

}
