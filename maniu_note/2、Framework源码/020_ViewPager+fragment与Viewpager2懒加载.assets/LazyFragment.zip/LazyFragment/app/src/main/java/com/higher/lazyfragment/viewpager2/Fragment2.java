package com.higher.lazyfragment.viewpager2;

import android.view.View;
import android.widget.TextView;

import com.higher.lazyfragment.R;

public class Fragment2 extends  BaseFragment{
    private TextView textView;
    @Override
    protected int getLayoutId() {
        return R.layout.fragment;
    }

    @Override
    protected void initView(View rootView) {
        textView = rootView.findViewById(R.id.fragment_tv);
    }


}
