package com.higher.lazyfragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class LazyFragment extends LogFragment {

    private View viewRoot;

    private boolean isShow;

    private boolean isLoaded;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        viewRoot = inflater.inflate(getLayoutId(), container, false);
        initView(viewRoot);
        if (!isShow && getUserVisibleHint()) {
            dispatchVisibleHint(true);
        }
        return viewRoot;
    }

    protected abstract int getLayoutId();

    protected abstract void initView(View viewRoot);

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (viewRoot != null) {
            if (!isShow && isVisibleToUser) {
                //当前从不可见变为可见
                dispatchVisibleHint(true);
            } else if (isShow && !isVisibleToUser) {
                //当前从可见变为不可见
                dispatchVisibleHint(false);
            }
        }
    }

    private void dispatchVisibleHint(boolean isVisible) {
        isShow = isVisible;
        if (isVisible) {
            if (!isLoaded) {
                Log.e(TAG, "开始加载" + getClass().getName());
                isLoaded = true;
                loadData();
            }
        } else {
            Log.e(TAG, "停止加载" + getClass().getName());
            stopLoadData();
        }
    }

    protected void stopLoadData() {
    }

    protected void loadData() {
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        viewRoot = null;
        isShow = false;
        isLoaded = false;
    }
}
