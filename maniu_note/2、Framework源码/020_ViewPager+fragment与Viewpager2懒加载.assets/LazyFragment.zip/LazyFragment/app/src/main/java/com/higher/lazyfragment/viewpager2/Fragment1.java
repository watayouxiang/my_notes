package com.higher.lazyfragment.viewpager2;

import android.view.View;
import android.widget.TextView;

import com.higher.lazyfragment.R;

public class Fragment1 extends BaseFragment {


    @Override
    protected int getLayoutId() {
        return R.layout.fragment;
    }

    private TextView textView;
    @Override
    protected void initView(View rootView) {
        textView = rootView.findViewById(R.id.fragment_tv);
        textView.setText("初始化页面");
    }


}
