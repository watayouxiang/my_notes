package com.higher.lazyfragment.fragment;

import android.view.View;
import android.widget.TextView;

import com.higher.lazyfragment.LazyFragment;
import com.higher.lazyfragment.LazyFragment2;
import com.higher.lazyfragment.R;

public class Fragment3 extends LazyFragment {

    private TextView textView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment;
    }

    @Override
    protected void initView(View rootView) {
        textView = rootView.findViewById(R.id.fragment_tv);
    }

    @Override
    public void loadData() {
        super.loadData();
        textView.setText("加载数据");
    }

}
