package com.higher.lazyfragment;

import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import com.higher.lazyfragment.viewpager2.BaseFragment;
import com.higher.lazyfragment.viewpager2.Fragment1;
import com.higher.lazyfragment.viewpager2.Fragment2;
import com.higher.lazyfragment.viewpager2.Fragment3;
import com.higher.lazyfragment.viewpager2.Fragment4;

import java.util.ArrayList;

public class ThirdActivity extends AppCompatActivity {

    private ViewPager2 viewPager2;

    private TabLayout tabLayout;

    private ArrayList<BaseFragment> fragments;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        initView();
    }

    private void initView() {
        fragments = new ArrayList<>();
        viewPager2 = findViewById(R.id.activity_second_viewPager);
        tabLayout = findViewById(R.id.activity_tabLayout);
        fragments.add(new Fragment1());
        fragments.add(new Fragment2());
        fragments.add(new Fragment3());
        fragments.add(new Fragment4());
        //viewpager 对应的是
//        FragmentStatePagerAdapter 是viewpager
        //FragmentPagerAdapter  不会真正去销毁
        // FragmentStateAdapter

        //viewPager2 里面是个recyclerView.
        //RecyclerView.Adapter
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this) {
            @Override
            public int getItemCount() {
                return fragments.size();
            }

            @NonNull
            @Override
            public Fragment createFragment(int position) {
                return fragments.get(position);
            }
        };
        viewPager2.setAdapter(fragmentStateAdapter);
        TabLayoutMediator tabLayoutMediator = new TabLayoutMediator(tabLayout, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {

            }
        });
        tabLayoutMediator.attach();
        tabLayout.getTabAt(0).setText("Tab 1");
        tabLayout.getTabAt(1).setText("Tab 2");
        tabLayout.getTabAt(2).setText("Tab 3");
        tabLayout.getTabAt(3).setText("Tab 4");
//        viewPager2.setOffscreenPageLimit(3);\
    }
}
