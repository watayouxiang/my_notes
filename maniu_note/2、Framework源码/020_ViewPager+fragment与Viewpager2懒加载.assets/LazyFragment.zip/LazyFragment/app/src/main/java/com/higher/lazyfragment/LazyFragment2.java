package com.higher.lazyfragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class LazyFragment2 extends LogFragment {

    View viewRoot;

    //当前状态
    private boolean currentState;

    // 是否加载过
    private boolean isLoaded;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        viewRoot = inflater.inflate(getLayoutId(), container, false);
        initView(viewRoot);
        if (!currentState && getUserVisibleHint()) {
            //当我们当前状态从不显示 ——》显示
            dispatcherUserVisible(true);
        }
        return viewRoot;
    }

    protected abstract void initView(View viewRoot);

    protected abstract int getLayoutId();

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (viewRoot != null) {
            if (!currentState && isVisibleToUser) {//fragment显示了
                dispatcherUserVisible(true);
            } else if (currentState && isVisibleToUser) { //fragment隐藏
                dispatcherUserVisible(false);
            }
        }

    }

    private void dispatcherUserVisible(boolean isVisible) {
        currentState = isVisible;
        if (isVisible) {
            if (!isLoaded) {
                isLoaded = true;
                Log.e(TAG, "loadData" + getClass().getName());
                loadData();
            }

        } else {
            stopLoadData();
        }
    }

    /**
     * 停止加载数据
     */
    protected void stopLoadData() {

    }

    /**
     * 开始加载数据
     */
    protected void loadData() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        currentState = false;
        viewRoot = null;
        isLoaded = false;
    }
}
