package com.higher.lazyfragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;

import com.higher.lazyfragment.viewpager2.Fragment1;


public class MainActivity extends AppCompatActivity {
    public static String TAG = "MANIU";

    FragmentTransaction fragmentTransaction;
    FragmentManager fragmentManager;
    Fragment1 fragment1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.activity_frameLayout, new Fragment1(), "fragment1");
        //生成一个op对象，添加到ops数组中 ，所有的操作，其实是添加一个op对象到ops数组中
//        fragmentTransaction.remove();
//        fragmentTransaction.replace();
//        fragmentTransaction.hide();
//        fragmentTransaction.show();

        //当Activity 发生状态变化的时候，commitAllowingStateLoss不会抛异常
        //用commit，是使用hanlder发消息，异步执行
        fragmentTransaction.commit();
        fragmentTransaction.commitAllowingStateLoss();
        //是同步执行，马上执行
        fragmentTransaction.commitNow();
        fragmentTransaction.commitNowAllowingStateLoss();

//        fragmentTransaction.addToBackStack()


//        fragmentManager.findFragmentByTag();
//        fragmentManager.findFragmentById()

        fragment1 = new Fragment1();
//        findViewById(R.id.activity_btn_add).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                fragmentManager.beginTransaction().add(fragment1, "fragment1").commit();
//            }
//        });
//        findViewById(R.id.activity_btn_remove).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                fragmentManager.beginTransaction().hide(fragment1).commit();
//            }
//        });
    }

    //就是把所有的fragment，全部存到fragmentManagerState这个类
    //active
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment1 = fragmentManager.findFragmentByTag("fragment1");
        fragmentTransaction.show(fragment1);
        fragmentTransaction.commitNowAllowingStateLoss();
    }
}